from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import json
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Literal
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt as pyjwt

from emergentintegrations.llm.chat import LlmChat, UserMessage

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALGO = "HS256"
EMERGENT_LLM_KEY = os.environ['EMERGENT_LLM_KEY']

app = FastAPI()
api_router = APIRouter(prefix="/api")
security = HTTPBearer()


# ===== Models =====
class UserSignup(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class GoogleAuthRequest(BaseModel):
    session_token: str

class FirebaseAuthRequest(BaseModel):
    id_token: str

class UserProfile(BaseModel):
    age: int
    gender: Literal["male", "female"]
    height_cm: float
    weight_kg: float
    activity_level: Literal["sedentary", "light", "moderate", "active", "very_active"]
    goal: Literal["lose", "cut", "maintain", "bulk"]
    language: Optional[str] = "ar"

class WeightLog(BaseModel):
    weight_kg: float

class FoodLog(BaseModel):
    name: str
    calories: float
    protein: float = 0
    carbs: float = 0
    fats: float = 0
    meal_type: Optional[str] = "snack"  # breakfast/lunch/dinner/snack

class PlanRequest(BaseModel):
    language: Optional[str] = "ar"

class FoodEstimate(BaseModel):
    description: str
    language: Optional[str] = "ar"

class RunSession(BaseModel):
    distance_km: float
    duration_seconds: int
    calories: float
    path: List[List[float]] = []

class DailyGoal(BaseModel):
    distance_km: float



# ===== Helpers =====
def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def verify_password(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())

def create_token(user_id: str) -> str:
    payload = {
        "user_id": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=30)
    }
    return pyjwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = pyjwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGO])
        user_id = payload.get("user_id")
        user = await db.users.find_one({"id": user_id}, {"_id": 0, "password": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except pyjwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


def calculate_bmr(weight_kg: float, height_cm: float, age: int, gender: str) -> float:
    # Mifflin-St Jeor
    if gender == "male":
        return 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    return 10 * weight_kg + 6.25 * height_cm - 5 * age - 161

def calculate_tdee(bmr: float, activity_level: str) -> float:
    multipliers = {
        "sedentary": 1.2,
        "light": 1.375,
        "moderate": 1.55,
        "active": 1.725,
        "very_active": 1.9
    }
    return bmr * multipliers.get(activity_level, 1.2)

def calculate_goal_calories(tdee: float, goal: str) -> float:
    if goal == "lose":
        return tdee - 500
    if goal == "cut":
        return tdee - 300
    if goal == "bulk":
        return tdee + 400
    return tdee  # maintain

def calculate_macros(calories: float, goal: str, weight_kg: float):
    # Protein: 2g/kg (cut/bulk) or 1.6g/kg (maintain/lose)
    if goal in ["cut", "bulk"]:
        protein_g = 2.0 * weight_kg
    else:
        protein_g = 1.8 * weight_kg
    protein_cal = protein_g * 4
    # Fats: 25% of calories
    fat_cal = calories * 0.25
    fat_g = fat_cal / 9
    # Carbs: rest
    carb_cal = calories - protein_cal - fat_cal
    carb_g = max(carb_cal / 4, 0)
    return {
        "protein_g": round(protein_g),
        "carbs_g": round(carb_g),
        "fats_g": round(fat_g)
    }


# ===== Auth =====
@api_router.post("/auth/signup")
async def signup(data: UserSignup):
    existing = await db.users.find_one({"email": data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    user_id = str(uuid.uuid4())
    user_doc = {
        "id": user_id,
        "email": data.email,
        "name": data.name,
        "password": hash_password(data.password),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "profile": None,
        "language": "ar"
    }
    await db.users.insert_one(user_doc)
    token = create_token(user_id)
    return {
        "token": token,
        "user": {"id": user_id, "email": data.email, "name": data.name, "profile": None, "language": "ar"}
    }

@api_router.post("/auth/login")
async def login(data: UserLogin):
    user = await db.users.find_one({"email": data.email})
    if not user or not verify_password(data.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(user["id"])
    return {
        "token": token,
        "user": {
            "id": user["id"],
            "email": user["email"],
            "name": user["name"],
            "profile": user.get("profile"),
            "language": user.get("language", "ar")
        }
    }

@api_router.get("/auth/me")
async def me(user=Depends(get_current_user)):
    return user


@api_router.post("/auth/google")
async def google_auth(data: GoogleAuthRequest):
    """Verify Emergent session_token and create/login user, return our JWT."""
    import httpx
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(
                "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
                headers={"X-Session-ID": data.session_token}
            )
            if resp.status_code != 200:
                raise HTTPException(status_code=401, detail="Invalid Google session")
            info = resp.json()
        except httpx.HTTPError as e:
            raise HTTPException(status_code=500, detail=f"Auth verification failed: {e}")

    email = info.get("email")
    name = info.get("name") or email.split("@")[0]
    if not email:
        raise HTTPException(status_code=400, detail="No email in Google session")

    user = await db.users.find_one({"email": email})
    if not user:
        user_id = str(uuid.uuid4())
        user_doc = {
            "id": user_id,
            "email": email,
            "name": name,
            "password": None,  # Google user, no password
            "google_id": info.get("id"),
            "picture": info.get("picture"),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "profile": None,
            "language": "ar"
        }
        await db.users.insert_one(user_doc)
        user = user_doc
    else:
        # Update Google fields if missing
        update = {}
        if not user.get("google_id"):
            update["google_id"] = info.get("id")
        if info.get("picture"):
            update["picture"] = info.get("picture")
        if update:
            await db.users.update_one({"id": user["id"]}, {"$set": update})

    token = create_token(user["id"])
    return {
        "token": token,
        "user": {
            "id": user["id"],
            "email": user["email"],
            "name": user["name"],
            "profile": user.get("profile"),
            "language": user.get("language", "ar"),
            "picture": user.get("picture"),
        }
    }


# ===== Profile / Calorie Calc =====
@api_router.post("/profile")
async def save_profile(profile: UserProfile, user=Depends(get_current_user)):
    bmr = calculate_bmr(profile.weight_kg, profile.height_cm, profile.age, profile.gender)
    tdee = calculate_tdee(bmr, profile.activity_level)
    target_cal = calculate_goal_calories(tdee, profile.goal)
    macros = calculate_macros(target_cal, profile.goal, profile.weight_kg)

    profile_doc = profile.dict()
    profile_doc.update({
        "bmr": round(bmr),
        "tdee": round(tdee),
        "target_calories": round(target_cal),
        "macros": macros,
        "updated_at": datetime.now(timezone.utc).isoformat()
    })
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"profile": profile_doc, "language": profile.language}}
    )
    return profile_doc

@api_router.get("/profile")
async def get_profile(user=Depends(get_current_user)):
    if not user.get("profile"):
        raise HTTPException(status_code=404, detail="Profile not set")
    return user["profile"]


# ===== AI Plans =====
async def generate_plan_with_gemini(system_msg: str, user_prompt: str, session_key: str) -> str:
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_key,
        system_message=system_msg
    ).with_model("gemini", "gemini-3-flash-preview")
    response = await chat.send_message(UserMessage(text=user_prompt))
    return response

def extract_json(text: str):
    # Strip code fences
    text = text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    # find first { and last }
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        text = text[start:end+1]
    return json.loads(text)

@api_router.post("/plans/workout")
async def generate_workout(req: PlanRequest, user=Depends(get_current_user)):
    profile = user.get("profile")
    if not profile:
        raise HTTPException(status_code=400, detail="Profile required")

    lang = req.language or "ar"
    lang_inst = "Respond in Arabic." if lang == "ar" else "Respond in English."

    system_msg = (
        "You are an elite fitness coach. Generate a structured 7-day workout plan as PURE JSON only. "
        + lang_inst
    )
    prompt = f"""Create a 7-day workout plan for:
Age: {profile['age']}, Gender: {profile['gender']}, Weight: {profile['weight_kg']}kg, Height: {profile['height_cm']}cm
Goal: {profile['goal']} (lose=weight loss, cut=cutting/definition, bulk=muscle building, maintain=maintenance)
Activity: {profile['activity_level']}

Return ONLY valid JSON in this exact format (no markdown, no explanation):
{{
  "title": "Plan title",
  "summary": "Short 1-line summary",
  "days": [
    {{
      "day": "Day 1 / اليوم 1",
      "focus": "Chest & Triceps",
      "exercises": [
        {{"name": "Exercise name", "sets": 4, "reps": "8-12", "rest": "60s"}}
      ]
    }}
  ]
}}
Include 7 days with 4-6 exercises each. Include rest days where appropriate."""

    try:
        raw = await generate_plan_with_gemini(system_msg, prompt, f"workout_{user['id']}")
        plan = extract_json(raw)
    except Exception as e:
        logger.error(f"Workout plan error: {e}")
        raise HTTPException(status_code=500, detail=f"AI generation failed: {str(e)}")

    plan_doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "type": "workout",
        "language": lang,
        "plan": plan,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.plans.insert_one(plan_doc.copy())
    return {"plan": plan, "id": plan_doc["id"]}

@api_router.post("/plans/nutrition")
async def generate_nutrition(req: PlanRequest, user=Depends(get_current_user)):
    profile = user.get("profile")
    if not profile:
        raise HTTPException(status_code=400, detail="Profile required")

    lang = req.language or "ar"
    lang_inst = "Respond in Arabic." if lang == "ar" else "Respond in English."

    target_cal = profile.get("target_calories")
    macros = profile.get("macros", {})

    system_msg = (
        "You are an expert nutritionist. Generate a daily meal plan as PURE JSON only. "
        + lang_inst
    )
    prompt = f"""Create a daily nutrition plan for:
Target calories: {target_cal} kcal/day
Macros: Protein {macros.get('protein_g')}g, Carbs {macros.get('carbs_g')}g, Fats {macros.get('fats_g')}g
Goal: {profile['goal']}
Weight: {profile['weight_kg']}kg

Return ONLY valid JSON (no markdown):
{{
  "title": "Plan title",
  "daily_calories": {target_cal},
  "meals": [
    {{
      "meal": "Breakfast / الفطور",
      "items": [
        {{"name": "Food name", "amount": "100g", "calories": 200, "protein": 20, "carbs": 15, "fats": 5}}
      ],
      "total_calories": 500
    }}
  ],
  "tips": ["tip 1", "tip 2", "tip 3"]
}}
Include 4-5 meals (breakfast, snack, lunch, snack, dinner). Use common foods."""

    try:
        raw = await generate_plan_with_gemini(system_msg, prompt, f"nutrition_{user['id']}")
        plan = extract_json(raw)
    except Exception as e:
        logger.error(f"Nutrition plan error: {e}")
        raise HTTPException(status_code=500, detail=f"AI generation failed: {str(e)}")

    plan_doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "type": "nutrition",
        "language": lang,
        "plan": plan,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.plans.insert_one(plan_doc.copy())
    return {"plan": plan, "id": plan_doc["id"]}

@api_router.get("/plans/latest/{plan_type}")
async def get_latest_plan(plan_type: str, user=Depends(get_current_user)):
    plan_doc = await db.plans.find_one(
        {"user_id": user["id"], "type": plan_type},
        {"_id": 0},
        sort=[("created_at", -1)]
    )
    if not plan_doc:
        raise HTTPException(status_code=404, detail="No plan found")
    return plan_doc


# ===== Food Log =====
@api_router.post("/food/log")
async def log_food(food: FoodLog, user=Depends(get_current_user)):
    today = datetime.now(timezone.utc).date().isoformat()
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "date": today,
        "name": food.name,
        "calories": food.calories,
        "protein": food.protein,
        "carbs": food.carbs,
        "fats": food.fats,
        "meal_type": food.meal_type,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.food_logs.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/food/today")
async def food_today(user=Depends(get_current_user)):
    today = datetime.now(timezone.utc).date().isoformat()
    logs = await db.food_logs.find(
        {"user_id": user["id"], "date": today},
        {"_id": 0}
    ).to_list(200)
    totals = {
        "calories": sum(l["calories"] for l in logs),
        "protein": sum(l["protein"] for l in logs),
        "carbs": sum(l["carbs"] for l in logs),
        "fats": sum(l["fats"] for l in logs)
    }
    return {"logs": logs, "totals": totals, "date": today}

@api_router.delete("/food/log/{log_id}")
async def delete_food_log(log_id: str, user=Depends(get_current_user)):
    result = await db.food_logs.delete_one({"id": log_id, "user_id": user["id"]})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    return {"ok": True}


# ===== Weight Tracking =====
@api_router.post("/weight/log")
async def log_weight(data: WeightLog, user=Depends(get_current_user)):
    today = datetime.now(timezone.utc).date().isoformat()
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "date": today,
        "weight_kg": data.weight_kg,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.weight_logs.insert_one(doc.copy())
    # Recalculate profile metrics with new weight
    profile = user.get("profile")
    if profile:
        bmr = calculate_bmr(data.weight_kg, profile["height_cm"], profile["age"], profile["gender"])
        tdee = calculate_tdee(bmr, profile["activity_level"])
        target_cal = calculate_goal_calories(tdee, profile["goal"])
        macros = calculate_macros(target_cal, profile["goal"], data.weight_kg)
        await db.users.update_one(
            {"id": user["id"]},
            {"$set": {
                "profile.weight_kg": data.weight_kg,
                "profile.bmr": round(bmr),
                "profile.tdee": round(tdee),
                "profile.target_calories": round(target_cal),
                "profile.macros": macros,
            }}
        )
    else:
        await db.users.update_one(
            {"id": user["id"]},
            {"$set": {"profile.weight_kg": data.weight_kg}}
        )
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/weight/history")
async def weight_history(user=Depends(get_current_user)):
    logs = await db.weight_logs.find(
        {"user_id": user["id"]},
        {"_id": 0}
    ).sort("created_at", 1).to_list(365)
    return {"logs": logs}


@api_router.get("/")
async def root():
    return {"message": "Fitness API"}


FIREBASE_PROJECT_ID = "fitcore-78781"

@api_router.post("/auth/firebase")
async def firebase_auth(data: FirebaseAuthRequest):
    """Verify Firebase ID token, create/find user, return our JWT."""
    from google.oauth2 import id_token as google_id_token
    from google.auth.transport import requests as google_requests
    try:
        info = google_id_token.verify_firebase_token(
            data.id_token,
            google_requests.Request(),
            audience=FIREBASE_PROJECT_ID,
        )
    except Exception as e:
        logger.error(f"Firebase token verification failed: {e}")
        raise HTTPException(status_code=401, detail=f"Invalid Firebase token: {e}")

    email = info.get("email")
    name = info.get("name") or (email.split("@")[0] if email else "User")
    firebase_uid = info.get("user_id") or info.get("sub")
    if not email:
        raise HTTPException(status_code=400, detail="Firebase token missing email")

    user = await db.users.find_one({"email": email})
    if not user:
        user_id = str(uuid.uuid4())
        user_doc = {
            "id": user_id,
            "email": email,
            "name": name,
            "password": None,
            "firebase_uid": firebase_uid,
            "picture": info.get("picture"),
            "provider": info.get("firebase", {}).get("sign_in_provider", "firebase"),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "profile": None,
            "language": "ar"
        }
        await db.users.insert_one(user_doc)
        user = user_doc
    else:
        update = {"firebase_uid": firebase_uid}
        if info.get("picture") and not user.get("picture"):
            update["picture"] = info.get("picture")
        await db.users.update_one({"id": user["id"]}, {"$set": update})

    token = create_token(user["id"])
    return {
        "token": token,
        "user": {
            "id": user["id"],
            "email": user["email"],
            "name": user["name"],
            "profile": user.get("profile"),
            "language": user.get("language", "ar"),
            "picture": user.get("picture"),
        }
    }


# ===== AI Food Calorie Estimator =====
@api_router.post("/food/estimate")
async def estimate_food(data: FoodEstimate, user=Depends(get_current_user)):
    lang_inst = "Respond in Arabic." if data.language == "ar" else "Respond in English."
    system_msg = (
        "You are a nutrition database expert. Estimate calories and macros for the food described. "
        "Return ONLY valid JSON (no markdown). " + lang_inst
    )
    prompt = f"""Estimate nutrition for: "{data.description}"
Return JSON exactly like:
{{"name": "food name", "calories": 250, "protein": 15, "carbs": 30, "fats": 8, "amount": "100g"}}
Use realistic values. If amount unclear, assume 1 serving."""
    try:
        raw = await generate_plan_with_gemini(system_msg, prompt, f"estimate_{user['id']}")
        result = extract_json(raw)
    except Exception as e:
        logger.error(f"Estimate error: {e}")
        raise HTTPException(status_code=500, detail=f"AI estimate failed: {str(e)}")
    return result


# ===== Run Sessions =====
@api_router.post("/runs")
async def save_run(data: RunSession, user=Depends(get_current_user)):
    today = datetime.now(timezone.utc).date().isoformat()
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "date": today,
        "distance_km": data.distance_km,
        "duration_seconds": data.duration_seconds,
        "calories": data.calories,
        "path": data.path,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.runs.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/runs")
async def list_runs(user=Depends(get_current_user)):
    runs = await db.runs.find(
        {"user_id": user["id"]},
        {"_id": 0, "path": 0}  # exclude path for list view
    ).sort("created_at", -1).to_list(50)
    return {"runs": runs}

@api_router.get("/runs/stats")
async def run_stats(user=Depends(get_current_user)):
    today = datetime.now(timezone.utc).date()
    week_ago = (today - timedelta(days=7)).isoformat()
    today_str = today.isoformat()
    runs = await db.runs.find(
        {"user_id": user["id"], "date": {"$gte": week_ago}},
        {"_id": 0, "path": 0}
    ).to_list(200)
    week_total = sum(r["distance_km"] for r in runs)
    today_total = sum(r["distance_km"] for r in runs if r["date"] == today_str)
    return {
        "week_distance_km": round(week_total, 2),
        "week_sessions": len(runs),
        "today_distance_km": round(today_total, 2),
    }


# ===== Daily Goal =====
@api_router.post("/goals")
async def set_goal(data: DailyGoal, user=Depends(get_current_user)):
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"daily_run_goal_km": data.distance_km}}
    )
    return {"distance_km": data.distance_km}

@api_router.get("/goals")
async def get_goal(user=Depends(get_current_user)):
    u = await db.users.find_one({"id": user["id"]}, {"_id": 0, "daily_run_goal_km": 1})
    return {"distance_km": (u or {}).get("daily_run_goal_km", 5.0)}




# ===== WebSocket Manager =====
from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict

class ConnectionManager:
    def __init__(self):
        self.active: Dict[str, WebSocket] = {}

    async def connect(self, user_id: str, ws: WebSocket):
        await ws.accept()
        self.active[user_id] = ws

    def disconnect(self, user_id: str):
        self.active.pop(user_id, None)

    async def send_to(self, user_id: str, data: dict):
        ws = self.active.get(user_id)
        if ws:
            try:
                await ws.send_json(data)
            except Exception:
                self.disconnect(user_id)

manager = ConnectionManager()


# ===== Social Models =====
class UpdateSocialProfile(BaseModel):
    bio: Optional[str] = None
    avatar: Optional[str] = None

class PostCreate(BaseModel):
    content: str
    image: Optional[str] = None

class MessageSend(BaseModel):
    to_user_id: str
    content: str


# ===== Social Profile =====
@api_router.patch("/social/profile")
async def update_social_profile(data: UpdateSocialProfile, user=Depends(get_current_user)):
    update = {}
    if data.bio is not None:
        update["bio"] = data.bio
    if data.avatar is not None:
        update["avatar"] = data.avatar
    if update:
        await db.users.update_one({"id": user["id"]}, {"$set": update})
    u = await db.users.find_one({"id": user["id"]}, {"_id": 0, "password": 0})
    return {"bio": u.get("bio", ""), "avatar": u.get("avatar", u.get("picture", ""))}

@api_router.get("/social/profile/{user_id}")
async def get_social_profile(user_id: str, user=Depends(get_current_user)):
    u = await db.users.find_one({"id": user_id}, {"_id": 0, "password": 0})
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    return {
        "id": u["id"],
        "name": u["name"],
        "bio": u.get("bio", ""),
        "avatar": u.get("avatar", u.get("picture", "")),
        "goal": u.get("profile", {}).get("goal") if u.get("profile") else None,
    }

@api_router.get("/users/search")
async def search_users(q: str = "", user=Depends(get_current_user)):
    import re
    query: dict = {"id": {"$ne": user["id"]}}
    if q:
        safe_q = re.escape(q.lstrip("@"))
        query["$or"] = [
            {"name": {"$regex": safe_q, "$options": "i"}},
            {"username": {"$regex": safe_q, "$options": "i"}},
        ]
    users = await db.users.find(
        query, {"_id": 0, "id": 1, "name": 1, "username": 1, "bio": 1, "avatar": 1, "picture": 1}
    ).to_list(20)
    return {"users": [
        {"id": u["id"], "name": u["name"], "username": u.get("username", ""),
         "bio": u.get("bio", ""), "avatar": u.get("avatar", u.get("picture", ""))}
        for u in users
    ]}


# ===== Posts / Feed =====
@api_router.post("/posts")
async def create_post(data: PostCreate, user=Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar", user.get("picture", "")),
        "content": data.content,
        "image": data.image,
        "likes": [],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.posts.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/posts/feed")
async def get_feed(user=Depends(get_current_user)):
    posts = await db.posts.find({}, {"_id": 0}).sort("created_at", -1).to_list(50)
    return {"posts": posts}

@api_router.post("/posts/{post_id}/like")
async def toggle_like(post_id: str, user=Depends(get_current_user)):
    post = await db.posts.find_one({"id": post_id})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    likes: list = post.get("likes", [])
    if user["id"] in likes:
        likes.remove(user["id"])
        liked = False
    else:
        likes.append(user["id"])
        liked = True
    await db.posts.update_one({"id": post_id}, {"$set": {"likes": likes}})
    return {"likes": len(likes), "liked": liked}

@api_router.delete("/posts/{post_id}")
async def delete_post(post_id: str, user=Depends(get_current_user)):
    result = await db.posts.delete_one({"id": post_id, "user_id": user["id"]})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Not found")
    return {"ok": True}


# ===== Chat / Messages =====
@api_router.post("/messages")
async def send_message(data: MessageSend, user=Depends(get_current_user)):
    to_user = await db.users.find_one({"id": data.to_user_id}, {"_id": 0, "id": 1, "name": 1})
    if not to_user:
        raise HTTPException(status_code=404, detail="User not found")
    doc = {
        "id": str(uuid.uuid4()),
        "from_user_id": user["id"],
        "from_user_name": user["name"],
        "from_user_avatar": user.get("avatar", user.get("picture", "")),
        "to_user_id": data.to_user_id,
        "content": data.content,
        "read": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.messages.insert_one(doc.copy())
    msg = {k: v for k, v in doc.items() if k != "_id"}
    await manager.send_to(data.to_user_id, {"type": "message", "data": msg})
    return msg

@api_router.get("/messages/{other_user_id}")
async def get_conversation(other_user_id: str, user=Depends(get_current_user)):
    messages = await db.messages.find(
        {"$or": [
            {"from_user_id": user["id"], "to_user_id": other_user_id},
            {"from_user_id": other_user_id, "to_user_id": user["id"]},
        ]},
        {"_id": 0},
    ).sort("created_at", 1).to_list(300)
    await db.messages.update_many(
        {"from_user_id": other_user_id, "to_user_id": user["id"], "read": False},
        {"$set": {"read": True}},
    )
    return {"messages": messages}

@api_router.get("/conversations")
async def list_conversations(user=Depends(get_current_user)):
    pipeline = [
        {"$match": {"$or": [{"from_user_id": user["id"]}, {"to_user_id": user["id"]}]}},
        {"$sort": {"created_at": -1}},
        {"$group": {
            "_id": {"$cond": [
                {"$eq": ["$from_user_id", user["id"]]},
                "$to_user_id",
                "$from_user_id",
            ]},
            "last_message": {"$first": "$$ROOT"},
            "unread": {"$sum": {"$cond": [
                {"$and": [
                    {"$eq": ["$to_user_id", user["id"]]},
                    {"$eq": ["$read", False]},
                ]},
                1, 0,
            ]}},
        }},
    ]
    convos = await db.messages.aggregate(pipeline).to_list(50)
    result = []
    for c in convos:
        other_id = c["_id"]
        other = await db.users.find_one(
            {"id": other_id},
            {"_id": 0, "id": 1, "name": 1, "avatar": 1, "picture": 1},
        )
        if other:
            msg = c["last_message"]
            result.append({
                "user_id": other_id,
                "user_name": other["name"],
                "user_avatar": other.get("avatar", other.get("picture", "")),
                "last_message": msg.get("content", ""),
                "last_at": msg.get("created_at"),
                "unread": c["unread"],
            })
    return {"conversations": result}


# ===== Username System =====
class SetUsername(BaseModel):
    username: str

@api_router.patch("/user/username")
async def set_username(data: SetUsername, user=Depends(get_current_user)):
    import re as _re
    if not _re.match(r'^[a-zA-Z0-9_]{3,30}$', data.username):
        raise HTTPException(status_code=400, detail="Invalid username. Use 3-30 chars: letters, numbers, underscore.")
    existing = await db.users.find_one({"username": data.username.lower(), "id": {"$ne": user["id"]}})
    if existing:
        raise HTTPException(status_code=409, detail="Username already taken")
    await db.users.update_one({"id": user["id"]}, {"$set": {"username": data.username.lower()}})
    return {"username": data.username.lower()}

@api_router.get("/user/me/full")
async def get_full_me(user=Depends(get_current_user)):
    return {
        "id": user["id"], "name": user["name"], "email": user.get("email", ""),
        "username": user.get("username", ""), "bio": user.get("bio", ""),
        "avatar": user.get("avatar", user.get("picture", "")),
        "profile": user.get("profile"),
    }


# ===== Groups =====
class GroupCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    avatar: Optional[str] = ""
    member_ids: List[str] = []

class GroupMessageSend(BaseModel):
    content: str

class AddMemberRequest(BaseModel):
    user_id: str

@api_router.post("/groups")
async def create_group(data: GroupCreate, user=Depends(get_current_user)):
    group_id = str(uuid.uuid4())
    members = list(set([user["id"]] + data.member_ids))
    doc = {
        "id": group_id,
        "name": data.name,
        "description": data.description,
        "avatar": data.avatar,
        "created_by": user["id"],
        "members": members,
        "admins": [user["id"]],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.groups.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/groups")
async def list_groups(user=Depends(get_current_user)):
    groups = await db.groups.find({"members": user["id"]}, {"_id": 0}).to_list(50)
    result = []
    for g in groups:
        last_msg = await db.group_messages.find_one(
            {"group_id": g["id"]}, {"_id": 0}, sort=[("created_at", -1)]
        )
        result.append({
            **g,
            "last_message": last_msg.get("content", "") if last_msg else "",
            "last_at": last_msg.get("created_at") if last_msg else g["created_at"],
            "member_count": len(g.get("members", [])),
        })
    return {"groups": result}

@api_router.get("/groups/{group_id}")
async def get_group(group_id: str, user=Depends(get_current_user)):
    g = await db.groups.find_one({"id": group_id, "members": user["id"]}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found or not a member")
    return g

@api_router.post("/groups/{group_id}/members")
async def add_group_member(group_id: str, data: AddMemberRequest, user=Depends(get_current_user)):
    g = await db.groups.find_one({"id": group_id, "admins": user["id"]})
    if not g:
        raise HTTPException(status_code=403, detail="Only admins can add members")
    if data.user_id not in g.get("members", []):
        await db.groups.update_one({"id": group_id}, {"$push": {"members": data.user_id}})
    return {"ok": True}

@api_router.delete("/groups/{group_id}/leave")
async def leave_group(group_id: str, user=Depends(get_current_user)):
    await db.groups.update_one({"id": group_id}, {"$pull": {"members": user["id"]}})
    return {"ok": True}

@api_router.post("/groups/{group_id}/messages")
async def send_group_message(group_id: str, data: GroupMessageSend, user=Depends(get_current_user)):
    g = await db.groups.find_one({"id": group_id, "members": user["id"]})
    if not g:
        raise HTTPException(status_code=403, detail="Not a member")
    doc = {
        "id": str(uuid.uuid4()),
        "group_id": group_id,
        "from_user_id": user["id"],
        "from_user_name": user["name"],
        "from_user_avatar": user.get("avatar", user.get("picture", "")),
        "content": data.content,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.group_messages.insert_one(doc.copy())
    msg = {k: v for k, v in doc.items() if k != "_id"}
    for member_id in g.get("members", []):
        if member_id != user["id"]:
            await manager.send_to(member_id, {"type": "group_message", "group_id": group_id, "data": msg})
    return msg

@api_router.get("/groups/{group_id}/messages")
async def get_group_messages(group_id: str, user=Depends(get_current_user)):
    g = await db.groups.find_one({"id": group_id, "members": user["id"]})
    if not g:
        raise HTTPException(status_code=403, detail="Not a member")
    messages = await db.group_messages.find(
        {"group_id": group_id}, {"_id": 0}
    ).sort("created_at", 1).to_list(300)
    return {"messages": messages}


# ===== Channels =====
class ChannelCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    avatar: Optional[str] = ""

class ChannelPostCreate(BaseModel):
    content: str
    image: Optional[str] = None

@api_router.post("/channels")
async def create_channel(data: ChannelCreate, user=Depends(get_current_user)):
    channel_id = str(uuid.uuid4())
    doc = {
        "id": channel_id,
        "name": data.name,
        "description": data.description,
        "avatar": data.avatar,
        "created_by": user["id"],
        "subscribers": [user["id"]],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.channels.insert_one(doc.copy())
    return {k: v for k, v in doc.items() if k != "_id"}

@api_router.get("/channels")
async def list_all_channels(user=Depends(get_current_user)):
    channels = await db.channels.find({}, {"_id": 0}).to_list(100)
    result = []
    for c in channels:
        last_post = await db.channel_posts.find_one(
            {"channel_id": c["id"]}, {"_id": 0}, sort=[("created_at", -1)]
        )
        result.append({
            **c,
            "subscribed": user["id"] in c.get("subscribers", []),
            "subscriber_count": len(c.get("subscribers", [])),
            "last_post": last_post.get("content", "") if last_post else "",
            "last_at": last_post.get("created_at") if last_post else c["created_at"],
        })
    return {"channels": result}

@api_router.get("/channels/mine")
async def my_channels(user=Depends(get_current_user)):
    channels = await db.channels.find({"subscribers": user["id"]}, {"_id": 0}).to_list(50)
    result = []
    for c in channels:
        last_post = await db.channel_posts.find_one(
            {"channel_id": c["id"]}, {"_id": 0}, sort=[("created_at", -1)]
        )
        result.append({
            **c,
            "subscribed": True,
            "subscriber_count": len(c.get("subscribers", [])),
            "last_post": last_post.get("content", "") if last_post else "",
            "last_at": last_post.get("created_at") if last_post else c["created_at"],
        })
    return {"channels": result}

@api_router.post("/channels/{channel_id}/subscribe")
async def toggle_channel_subscribe(channel_id: str, user=Depends(get_current_user)):
    c = await db.channels.find_one({"id": channel_id})
    if not c:
        raise HTTPException(status_code=404, detail="Channel not found")
    if user["id"] in c.get("subscribers", []):
        await db.channels.update_one({"id": channel_id}, {"$pull": {"subscribers": user["id"]}})
        return {"subscribed": False}
    await db.channels.update_one({"id": channel_id}, {"$push": {"subscribers": user["id"]}})
    return {"subscribed": True}

@api_router.post("/channels/{channel_id}/posts")
async def post_to_channel(channel_id: str, data: ChannelPostCreate, user=Depends(get_current_user)):
    c = await db.channels.find_one({"id": channel_id, "created_by": user["id"]})
    if not c:
        raise HTTPException(status_code=403, detail="Only channel owner can post")
    doc = {
        "id": str(uuid.uuid4()),
        "channel_id": channel_id,
        "channel_name": c["name"],
        "content": data.content,
        "image": data.image,
        "views": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.channel_posts.insert_one(doc.copy())
    post = {k: v for k, v in doc.items() if k != "_id"}
    for sub_id in c.get("subscribers", []):
        if sub_id != user["id"]:
            await manager.send_to(sub_id, {"type": "channel_post", "channel_id": channel_id, "data": post})
    return post

@api_router.get("/channels/{channel_id}/posts")
async def get_channel_posts(channel_id: str, user=Depends(get_current_user)):
    c = await db.channels.find_one({"id": channel_id})
    if not c:
        raise HTTPException(status_code=404, detail="Not found")
    posts = await db.channel_posts.find(
        {"channel_id": channel_id}, {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return {
        "posts": posts,
        "channel": {k: v for k, v in c.items() if k != "_id"},
        "is_owner": c.get("created_by") == user["id"],
        "subscribed": user["id"] in c.get("subscribers", []),
    }


# ===== WebSocket endpoint =====
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str, token: str = ""):
    try:
        if token:
            payload = pyjwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
            if payload.get("user_id") != user_id:
                await websocket.close(code=4001)
                return
    except Exception:
        await websocket.close(code=4001)
        return
    await manager.connect(user_id, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            if data.get("type") == "typing":
                to_id = data.get("to_user_id")
                if to_id:
                    await manager.send_to(to_id, {
                        "type": "typing",
                        "from_user_id": user_id,
                    })
    except WebSocketDisconnect:
        manager.disconnect(user_id)


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
