import { useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput,
  Image, Modal, ActivityIndicator, KeyboardAvoidingView, Platform,
  ScrollView, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useFocusEffect } from 'expo-router';
import { useApp } from '../../src/AppContext';
import { api } from '../../src/api';
import { COLORS, SPACING, RADIUS } from '../../src/theme';
import { t } from '../../src/i18n';

type Tab = 'chats' | 'groups' | 'channels';

function Avatar({ uri, name, size = 50 }: { uri?: string; name: string; size?: number }) {
  const letter = (name || '?').charAt(0).toUpperCase();
  const colors = ['#C80000', '#8B0000', '#B71C1C', '#D32F2F', '#E53935'];
  const color = colors[letter.charCodeAt(0) % colors.length];
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '700', fontSize: size * 0.38 }}>{letter}</Text>
    </View>
  );
}

function timeShort(dateStr: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'الآن';
  if (mins < 60) return `${mins}د`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return d.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
}

export default function ChatMain() {
  const router = useRouter();
  const { user, lang } = useApp();
  const [tab, setTab] = useState<Tab>('chats');
  const [conversations, setConversations] = useState<any[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [showSearch, setShowSearch] = useState(false);
  const [showNewGroup, setShowNewGroup] = useState(false);
  const [showChannels, setShowChannels] = useState(false);

  // Search
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  // New Group
  const [groupName, setGroupName] = useState('');
  const [groupDesc, setGroupDesc] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<any[]>([]);
  const [memberSearch, setMemberSearch] = useState('');
  const [memberResults, setMemberResults] = useState<any[]>([]);
  const [creatingGroup, setCreatingGroup] = useState(false);

  // New Channel
  const [showNewChannel, setShowNewChannel] = useState(false);
  const [channelName, setChannelName] = useState('');
  const [channelDesc, setChannelDesc] = useState('');
  const [creatingChannel, setCreatingChannel] = useState(false);
  const [allChannels, setAllChannels] = useState<any[]>([]);

  const loadAll = async () => {
    try {
      const [convData, groupData, chanData] = await Promise.all([
        api.getConversations().catch(() => ({ conversations: [] })),
        api.listGroups().catch(() => ({ groups: [] })),
        api.myChannels().catch(() => ({ channels: [] })),
      ]);
      setConversations(convData.conversations || []);
      setGroups(groupData.groups || []);
      setChannels(chanData.channels || []);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { loadAll(); }, []));

  const handleSearch = async (q: string) => {
    setSearchQ(q);
    if (!q.trim()) { setSearchResults([]); return; }
    setSearching(true);
    try {
      const d = await api.searchUsers(q);
      setSearchResults(d.users || []);
    } catch {} finally { setSearching(false); }
  };

  const handleMemberSearch = async (q: string) => {
    setMemberSearch(q);
    if (!q.trim()) { setMemberResults([]); return; }
    try {
      const d = await api.searchUsers(q);
      setMemberResults((d.users || []).filter((u: any) => !selectedMembers.find(m => m.id === u.id)));
    } catch {}
  };

  const toggleMember = (u: any) => {
    setSelectedMembers(prev =>
      prev.find(m => m.id === u.id) ? prev.filter(m => m.id !== u.id) : [...prev, u]
    );
    setMemberResults(prev => prev.filter(r => r.id !== u.id));
  };

  const createGroup = async () => {
    if (!groupName.trim()) return;
    setCreatingGroup(true);
    try {
      const g = await api.createGroup(groupName.trim(), groupDesc.trim(), selectedMembers.map(m => m.id));
      setGroups(prev => [g, ...prev]);
      setShowNewGroup(false);
      setGroupName(''); setGroupDesc(''); setSelectedMembers([]);
      setTab('groups');
      router.push({ pathname: '/chat/group/[groupId]', params: { groupId: g.id, groupName: g.name } });
    } catch (e: any) {
      Alert.alert(t(lang, 'error'), e.message);
    } finally { setCreatingGroup(false); }
  };

  const createChannel = async () => {
    if (!channelName.trim()) return;
    setCreatingChannel(true);
    try {
      const c = await api.createChannel(channelName.trim(), channelDesc.trim());
      setChannels(prev => [c, ...prev]);
      setShowNewChannel(false);
      setChannelName(''); setChannelDesc('');
      setTab('channels');
    } catch (e: any) {
      Alert.alert(t(lang, 'error'), e.message);
    } finally { setCreatingChannel(false); }
  };

  const loadAllChannels = async () => {
    const d = await api.listAllChannels().catch(() => ({ channels: [] }));
    setAllChannels(d.channels || []);
    setShowChannels(true);
  };

  const handleSubscribe = async (channelId: string) => {
    try {
      const res = await api.subscribeChannel(channelId);
      setAllChannels(prev => prev.map(c => c.id === channelId ? { ...c, subscribed: res.subscribed } : c));
      if (res.subscribed) {
        const chan = allChannels.find(c => c.id === channelId);
        if (chan) setChannels(prev => [chan, ...prev.filter(c => c.id !== channelId)]);
      } else {
        setChannels(prev => prev.filter(c => c.id !== channelId));
      }
    } catch {}
  };

  const TABS: { key: Tab; label: string; icon: string }[] = [
    { key: 'chats', label: t(lang, 'chats'), icon: 'chatbubbles' },
    { key: 'groups', label: t(lang, 'groups'), icon: 'people' },
    { key: 'channels', label: t(lang, 'channels'), icon: 'megaphone' },
  ];

  const renderConvo = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.listItem}
      onPress={() => router.push({ pathname: '/chat/[userId]', params: { userId: item.user_id, userName: item.user_name } })}
      activeOpacity={0.7}
    >
      <Avatar uri={item.user_avatar} name={item.user_name} />
      <View style={styles.itemInfo}>
        <View style={styles.itemRow}>
          <Text style={styles.itemName}>{item.user_name}</Text>
          <Text style={styles.itemTime}>{timeShort(item.last_at)}</Text>
        </View>
        <View style={styles.itemRow}>
          <Text style={styles.itemSub} numberOfLines={1}>{item.last_message || '...'}</Text>
          {item.unread > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{item.unread}</Text></View>}
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderGroup = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.listItem}
      onPress={() => router.push({ pathname: '/chat/group/[groupId]', params: { groupId: item.id, groupName: item.name } })}
      activeOpacity={0.7}
    >
      <View style={styles.groupIcon}>
        <Ionicons name="people" size={22} color={COLORS.primary} />
      </View>
      <View style={styles.itemInfo}>
        <View style={styles.itemRow}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.itemTime}>{timeShort(item.last_at)}</Text>
        </View>
        <View style={styles.itemRow}>
          <Text style={styles.itemSub} numberOfLines={1}>{item.last_message || item.description || '...'}</Text>
          <Text style={styles.memberCount}>{item.member_count} {lang === 'ar' ? 'عضو' : 'members'}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderChannel = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.listItem}
      onPress={() => router.push({ pathname: '/chat/channel/[channelId]', params: { channelId: item.id, channelName: item.name } })}
      activeOpacity={0.7}
    >
      <View style={[styles.groupIcon, { backgroundColor: '#1A0000' }]}>
        <Ionicons name="megaphone" size={20} color={COLORS.primaryLight} />
      </View>
      <View style={styles.itemInfo}>
        <View style={styles.itemRow}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.itemTime}>{timeShort(item.last_at)}</Text>
        </View>
        <View style={styles.itemRow}>
          <Text style={styles.itemSub} numberOfLines={1}>{item.last_post || item.description || '...'}</Text>
          <Text style={styles.memberCount}>{item.subscriber_count} {t(lang, 'subscribers')}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  const currentData = tab === 'chats' ? conversations : tab === 'groups' ? groups : channels;
  const currentRender = tab === 'chats' ? renderConvo : tab === 'groups' ? renderGroup : renderChannel;
  const emptyLabel = tab === 'chats' ? t(lang, 'noConversations') : tab === 'groups' ? t(lang, 'noGroups') : t(lang, 'noChannels');

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      {/* ── Header ── */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>FitCore</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.hBtn} onPress={() => setShowSearch(true)}>
            <Ionicons name="search" size={22} color={COLORS.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.hBtn}
            onPress={() => tab === 'chats' ? setShowSearch(true) : tab === 'groups' ? setShowNewGroup(true) : loadAllChannels()}
          >
            <Ionicons name="create-outline" size={22} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* ── Tabs ── */}
      <View style={styles.tabBar}>
        {TABS.map(tb => (
          <TouchableOpacity key={tb.key} style={[styles.tabItem, tab === tb.key && styles.tabItemActive]} onPress={() => setTab(tb.key)}>
            <Ionicons name={tb.icon as any} size={16} color={tab === tb.key ? COLORS.primary : COLORS.textMuted} />
            <Text style={[styles.tabLabel, tab === tb.key && styles.tabLabelActive]}>{tb.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── List ── */}
      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={COLORS.primary} size="large" /></View>
      ) : (
        <FlatList
          data={currentData as any[]}
          keyExtractor={item => item.user_id || item.id}
          renderItem={currentRender as any}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name={tab === 'chats' ? 'chatbubbles-outline' : tab === 'groups' ? 'people-outline' : 'megaphone-outline'} size={60} color={COLORS.border} />
              <Text style={styles.emptyTitle}>{emptyLabel}</Text>
              {tab === 'channels' && (
                <TouchableOpacity style={styles.exploreBtn} onPress={loadAllChannels}>
                  <Text style={styles.exploreBtnText}>{t(lang, 'exploreChannels')}</Text>
                </TouchableOpacity>
              )}
              {tab === 'groups' && (
                <TouchableOpacity style={styles.exploreBtn} onPress={() => setShowNewGroup(true)}>
                  <Text style={styles.exploreBtnText}>{t(lang, 'newGroup')}</Text>
                </TouchableOpacity>
              )}
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* FAB */}
      {tab === 'channels' && (
        <TouchableOpacity style={styles.fab} onPress={() => setShowNewChannel(true)}>
          <Ionicons name="add" size={28} color="#fff" />
        </TouchableOpacity>
      )}
      {tab === 'groups' && (
        <TouchableOpacity style={styles.fab} onPress={() => setShowNewGroup(true)}>
          <Ionicons name="add" size={28} color="#fff" />
        </TouchableOpacity>
      )}
      {tab === 'chats' && (
        <TouchableOpacity style={styles.fab} onPress={() => setShowSearch(true)}>
          <Ionicons name="create-outline" size={24} color="#fff" />
        </TouchableOpacity>
      )}

      {/* ── Search / New Chat Modal ── */}
      <Modal visible={showSearch} animationType="slide" transparent onRequestClose={() => { setShowSearch(false); setSearchQ(''); setSearchResults([]); }}>
        <View style={styles.modalFull}>
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => { setShowSearch(false); setSearchQ(''); setSearchResults([]); }}>
                <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
              <View style={styles.searchBarInline}>
                <Ionicons name="search" size={16} color={COLORS.textMuted} />
                <TextInput
                  style={styles.searchInputInline}
                  value={searchQ}
                  onChangeText={handleSearch}
                  placeholder={t(lang, 'searchUsers')}
                  placeholderTextColor={COLORS.textMuted}
                  autoFocus
                />
                {searching && <ActivityIndicator color={COLORS.primary} size="small" />}
              </View>
            </View>
            <FlatList
              data={searchResults}
              keyExtractor={i => i.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.listItem}
                  onPress={() => { setShowSearch(false); setSearchQ(''); setSearchResults([]); router.push({ pathname: '/chat/[userId]', params: { userId: item.id, userName: item.name } }); }}
                >
                  <Avatar uri={item.avatar} name={item.name} />
                  <View style={styles.itemInfo}>
                    <Text style={styles.itemName}>{item.name}</Text>
                    {item.username ? <Text style={styles.itemUsername}>@{item.username}</Text> : null}
                    {item.bio ? <Text style={styles.itemSub} numberOfLines={1}>{item.bio}</Text> : null}
                  </View>
                </TouchableOpacity>
              )}
              ListEmptyComponent={searchQ.length > 1 && !searching ? <Text style={styles.noResults}>{lang === 'ar' ? 'لا توجد نتائج' : 'No results'}</Text> : null}
            />
          </SafeAreaView>
        </View>
      </Modal>

      {/* ── New Group Modal ── */}
      <Modal visible={showNewGroup} animationType="slide" transparent onRequestClose={() => setShowNewGroup(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={styles.modalFull}>
            <SafeAreaView style={{ flex: 1 }} edges={['top']}>
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setShowNewGroup(false)}>
                  <Ionicons name="close" size={24} color={COLORS.textPrimary} />
                </TouchableOpacity>
                <Text style={styles.modalTitle}>{t(lang, 'newGroup')}</Text>
                <TouchableOpacity onPress={createGroup} disabled={!groupName.trim() || creatingGroup}>
                  {creatingGroup ? <ActivityIndicator color={COLORS.primary} /> : <Text style={[styles.modalAction, !groupName.trim() && { opacity: 0.3 }]}>{t(lang, 'createGroup')}</Text>}
                </TouchableOpacity>
              </View>
              <ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps="handled">
                <View style={styles.inputSection}>
                  <TextInput style={styles.modalInput} value={groupName} onChangeText={setGroupName} placeholder={t(lang, 'groupName')} placeholderTextColor={COLORS.textMuted} />
                  <TextInput style={styles.modalInput} value={groupDesc} onChangeText={setGroupDesc} placeholder={t(lang, 'groupDesc')} placeholderTextColor={COLORS.textMuted} />
                </View>
                {selectedMembers.length > 0 && (
                  <View style={styles.selectedWrap}>
                    {selectedMembers.map(m => (
                      <TouchableOpacity key={m.id} style={styles.selectedChip} onPress={() => setSelectedMembers(prev => prev.filter(x => x.id !== m.id))}>
                        <Avatar uri={m.avatar} name={m.name} size={28} />
                        <Text style={styles.chipName}>{m.name}</Text>
                        <Ionicons name="close-circle" size={14} color={COLORS.textMuted} />
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
                <View style={styles.inputSection}>
                  <Text style={styles.sectionLabel}>{t(lang, 'addMembers')}</Text>
                  <View style={styles.searchBarInline}>
                    <Ionicons name="search" size={16} color={COLORS.textMuted} />
                    <TextInput style={styles.searchInputInline} value={memberSearch} onChangeText={handleMemberSearch} placeholder={t(lang, 'searchUsers')} placeholderTextColor={COLORS.textMuted} />
                  </View>
                </View>
                {memberResults.map(item => (
                  <TouchableOpacity key={item.id} style={styles.listItem} onPress={() => toggleMember(item)}>
                    <Avatar uri={item.avatar} name={item.name} />
                    <View style={styles.itemInfo}>
                      <Text style={styles.itemName}>{item.name}</Text>
                      {item.username ? <Text style={styles.itemUsername}>@{item.username}</Text> : null}
                    </View>
                    <Ionicons name="add-circle-outline" size={22} color={COLORS.primary} />
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </SafeAreaView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* ── New Channel Modal ── */}
      <Modal visible={showNewChannel} animationType="slide" transparent onRequestClose={() => setShowNewChannel(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={styles.modalFull}>
            <SafeAreaView style={{ flex: 1 }} edges={['top']}>
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setShowNewChannel(false)}>
                  <Ionicons name="close" size={24} color={COLORS.textPrimary} />
                </TouchableOpacity>
                <Text style={styles.modalTitle}>{t(lang, 'newChannel')}</Text>
                <TouchableOpacity onPress={createChannel} disabled={!channelName.trim() || creatingChannel}>
                  {creatingChannel ? <ActivityIndicator color={COLORS.primary} /> : <Text style={[styles.modalAction, !channelName.trim() && { opacity: 0.3 }]}>{t(lang, 'createChannel')}</Text>}
                </TouchableOpacity>
              </View>
              <View style={styles.inputSection}>
                <TextInput style={styles.modalInput} value={channelName} onChangeText={setChannelName} placeholder={t(lang, 'channelName')} placeholderTextColor={COLORS.textMuted} autoFocus />
                <TextInput style={styles.modalInput} value={channelDesc} onChangeText={setChannelDesc} placeholder={t(lang, 'channelDesc')} placeholderTextColor={COLORS.textMuted} />
              </View>
            </SafeAreaView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* ── Explore Channels Modal ── */}
      <Modal visible={showChannels} animationType="slide" transparent onRequestClose={() => setShowChannels(false)}>
        <View style={styles.modalFull}>
          <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowChannels(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>{t(lang, 'allChannels')}</Text>
              <TouchableOpacity onPress={() => { setShowChannels(false); setShowNewChannel(true); }}>
                <Ionicons name="add" size={24} color={COLORS.primary} />
              </TouchableOpacity>
            </View>
            <FlatList
              data={allChannels}
              keyExtractor={i => i.id}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.listItem}
                  onPress={() => { setShowChannels(false); router.push({ pathname: '/chat/channel/[channelId]', params: { channelId: item.id, channelName: item.name } }); }}
                >
                  <View style={[styles.groupIcon, { backgroundColor: '#1A0000' }]}>
                    <Ionicons name="megaphone" size={20} color={COLORS.primaryLight} />
                  </View>
                  <View style={styles.itemInfo}>
                    <Text style={styles.itemName}>{item.name}</Text>
                    <Text style={styles.itemSub}>{item.subscriber_count} {t(lang, 'subscribers')}</Text>
                  </View>
                  <TouchableOpacity style={[styles.subBtn, item.subscribed && styles.subBtnActive]} onPress={() => handleSubscribe(item.id)}>
                    <Text style={[styles.subBtnText, item.subscribed && styles.subBtnTextActive]}>{item.subscribed ? t(lang, 'subscribed') : t(lang, 'subscribe')}</Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              )}
              ListEmptyComponent={<Text style={styles.noResults}>{t(lang, 'noChannels')}</Text>}
            />
          </SafeAreaView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.md, paddingVertical: 12,
    backgroundColor: COLORS.header, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerTitle: { color: COLORS.textPrimary, fontSize: 20, fontWeight: '800', letterSpacing: -0.5 },
  headerActions: { flexDirection: 'row', gap: 4 },
  hBtn: { padding: 8 },
  tabBar: {
    flexDirection: 'row', backgroundColor: COLORS.header,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  tabItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10 },
  tabItemActive: { borderBottomWidth: 2, borderBottomColor: COLORS.primary },
  tabLabel: { color: COLORS.textMuted, fontSize: 12, fontWeight: '600' },
  tabLabelActive: { color: COLORS.primary, fontWeight: '700' },
  listItem: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.md,
    paddingHorizontal: SPACING.md, paddingVertical: 12,
    backgroundColor: COLORS.background,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: COLORS.separator,
  },
  itemInfo: { flex: 1 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  itemName: { color: COLORS.textPrimary, fontSize: 15, fontWeight: '600' },
  itemUsername: { color: COLORS.textMuted, fontSize: 12 },
  itemSub: { color: COLORS.textMuted, fontSize: 13, flex: 1, marginRight: SPACING.sm },
  itemTime: { color: COLORS.textMuted, fontSize: 11 },
  badge: {
    backgroundColor: COLORS.unread, borderRadius: 10, minWidth: 20, height: 20,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4,
  },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: '800' },
  memberCount: { color: COLORS.textMuted, fontSize: 11 },
  groupIcon: {
    width: 50, height: 50, borderRadius: 25,
    backgroundColor: '#1A0A0A', alignItems: 'center', justifyContent: 'center',
  },
  emptyWrap: { alignItems: 'center', justifyContent: 'center', paddingTop: 100, gap: SPACING.md },
  emptyTitle: { color: COLORS.textMuted, fontSize: 16 },
  exploreBtn: { marginTop: SPACING.sm, backgroundColor: COLORS.primary, paddingHorizontal: SPACING.lg, paddingVertical: 10, borderRadius: RADIUS.xl },
  exploreBtnText: { color: '#fff', fontWeight: '700' },
  fab: {
    position: 'absolute', bottom: 24, right: 24,
    backgroundColor: COLORS.primary, width: 56, height: 56, borderRadius: 28,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 8, elevation: 8,
  },
  modalFull: { flex: 1, backgroundColor: COLORS.background },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.md, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    backgroundColor: COLORS.header,
  },
  modalTitle: { color: COLORS.textPrimary, fontSize: 17, fontWeight: '700' },
  modalAction: { color: COLORS.primary, fontSize: 15, fontWeight: '700' },
  inputSection: { padding: SPACING.md, gap: SPACING.sm },
  sectionLabel: { color: COLORS.textMuted, fontSize: 12, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 },
  modalInput: {
    backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.md,
    padding: SPACING.md, color: COLORS.textPrimary, fontSize: 15,
    borderWidth: 1, borderColor: COLORS.border,
  },
  searchBarInline: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.xl,
    paddingHorizontal: SPACING.md, paddingVertical: 10,
    borderWidth: 1, borderColor: COLORS.border,
  },
  searchInputInline: { flex: 1, color: COLORS.textPrimary, fontSize: 15 },
  noResults: { color: COLORS.textMuted, textAlign: 'center', paddingVertical: SPACING.xl },
  selectedWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: SPACING.md },
  selectedChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.xl,
    paddingHorizontal: 10, paddingVertical: 6, borderWidth: 1, borderColor: COLORS.border,
  },
  chipName: { color: COLORS.textPrimary, fontSize: 13 },
  subBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: RADIUS.xl, borderWidth: 1, borderColor: COLORS.primary },
  subBtnActive: { backgroundColor: COLORS.primary },
  subBtnText: { color: COLORS.primary, fontSize: 12, fontWeight: '700' },
  subBtnTextActive: { color: '#fff' },
});
