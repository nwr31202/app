import { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput,
  Image, Modal, KeyboardAvoidingView, Platform, Alert, ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import { useApp } from '../../src/AppContext';
import { api } from '../../src/api';
import { COLORS, SPACING, RADIUS } from '../../src/theme';
import { t } from '../../src/i18n';

function timeAgo(dateStr: string, lang: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return lang === 'ar' ? 'الآن' : 'Just now';
  if (mins < 60) return lang === 'ar' ? `${mins}د` : `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return lang === 'ar' ? `${hrs}س` : `${hrs}h`;
  return lang === 'ar' ? `${Math.floor(hrs / 24)}ي` : `${Math.floor(hrs / 24)}d`;
}

function Avatar({ uri, name, size = 40 }: { uri?: string; name: string; size?: number }) {
  const letter = (name || '?').charAt(0).toUpperCase();
  const colors = ['#C80000', '#8B0000', '#B71C1C', '#7B1FA2', '#1565C0'];
  const color = colors[letter.charCodeAt(0) % colors.length];
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '700', fontSize: size * 0.4 }}>{letter}</Text>
    </View>
  );
}

export default function Community() {
  const { user, lang } = useApp();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [posting, setPosting] = useState(false);

  const load = async () => {
    try {
      const data = await api.getFeed();
      setPosts(data.posts || []);
    } catch {} finally { setLoading(false); setRefreshing(false); }
  };

  useFocusEffect(useCallback(() => { load(); }, []));

  const submitPost = async () => {
    if (!content.trim()) return;
    setPosting(true);
    try {
      const p = await api.createPost(content.trim(), imageUrl.trim() || undefined);
      setPosts(prev => [p, ...prev]);
      setContent(''); setImageUrl(''); setShowCreate(false);
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); }
    finally { setPosting(false); }
  };

  const handleLike = async (postId: string) => {
    try {
      const res = await api.likePost(postId);
      setPosts(prev => prev.map(p => p.id === postId ? { ...p, likes: Array(res.likes).fill(''), _liked: res.liked } : p));
    } catch {}
  };

  const handleDelete = (postId: string) => {
    Alert.alert(t(lang, 'delete'), lang === 'ar' ? 'حذف هذا المنشور؟' : 'Delete this post?', [
      { text: lang === 'ar' ? 'إلغاء' : 'Cancel', style: 'cancel' },
      { text: t(lang, 'delete'), style: 'destructive', onPress: async () => { try { await api.deletePost(postId); setPosts(prev => prev.filter(p => p.id !== postId)); } catch {} } },
    ]);
  };

  const renderPost = ({ item }: { item: any }) => {
    const isOwn = item.user_id === user?.id;
    const liked = item._liked || (Array.isArray(item.likes) && item.likes.includes(user?.id));
    const likeCount = Array.isArray(item.likes) ? item.likes.length : (item.likes || 0);

    return (
      <View style={styles.postCard}>
        <View style={styles.postHeader}>
          <Avatar uri={item.user_avatar} name={item.user_name} size={42} />
          <View style={{ flex: 1 }}>
            <Text style={styles.postUserName}>{item.user_name}</Text>
            <Text style={styles.postTime}>{timeAgo(item.created_at, lang)}</Text>
          </View>
          {isOwn && (
            <TouchableOpacity onPress={() => handleDelete(item.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="ellipsis-vertical" size={18} color={COLORS.textMuted} />
            </TouchableOpacity>
          )}
        </View>

        <Text style={styles.postContent}>{item.content}</Text>

        {item.image ? <Image source={{ uri: item.image }} style={styles.postImage} resizeMode="cover" /> : null}

        <View style={styles.postFooter}>
          <TouchableOpacity style={styles.likeBtn} onPress={() => handleLike(item.id)} activeOpacity={0.8}>
            <Ionicons name={liked ? 'heart' : 'heart-outline'} size={20} color={liked ? COLORS.primary : COLORS.textMuted} />
            {likeCount > 0 && <Text style={[styles.likeCount, liked && { color: COLORS.primary }]}>{likeCount}</Text>}
          </TouchableOpacity>
          <View style={styles.footerRight}>
            <Ionicons name="share-social-outline" size={18} color={COLORS.textMuted} />
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerSub}>{t(lang, 'community').toUpperCase()}</Text>
          <Text style={styles.headerTitle}>{t(lang, 'feed')}</Text>
        </View>
        <TouchableOpacity style={styles.createBtn} onPress={() => setShowCreate(true)} activeOpacity={0.85}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.createBtnText}>{t(lang, 'newPost')}</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={COLORS.primary} size="large" /></View>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={item => item.id}
          renderItem={renderPost}
          contentContainerStyle={[styles.list, posts.length === 0 && styles.listEmpty]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={COLORS.primary} />}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name="globe-outline" size={60} color={COLORS.border} />
              <Text style={styles.emptyTitle}>{t(lang, 'noPostsYet')}</Text>
              <Text style={styles.emptySubtitle}>{t(lang, 'beFirst')}</Text>
            </View>
          }
        />
      )}

      <Modal visible={showCreate} animationType="slide" transparent onRequestClose={() => setShowCreate(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setShowCreate(false)}>
                <Ionicons name="close" size={24} color={COLORS.textSecondary} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>{t(lang, 'newPost')}</Text>
              <TouchableOpacity
                style={[styles.postBtn, (!content.trim() || posting) && { opacity: 0.4 }]}
                onPress={submitPost}
                disabled={!content.trim() || posting}
              >
                {posting ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.postBtnText}>{t(lang, 'post')}</Text>}
              </TouchableOpacity>
            </View>
            <View style={styles.createRow}>
              <Avatar uri={user?.avatar || user?.picture} name={user?.name || '?'} size={40} />
              <TextInput
                style={styles.postInput}
                value={content}
                onChangeText={setContent}
                placeholder={t(lang, 'writePost')}
                placeholderTextColor={COLORS.textMuted}
                multiline
                autoFocus
                textAlignVertical="top"
              />
            </View>
            <TextInput
              style={styles.imageInput}
              value={imageUrl}
              onChangeText={setImageUrl}
              placeholder={t(lang, 'addImageUrl')}
              placeholderTextColor={COLORS.textMuted}
              autoCapitalize="none"
              autoCorrect={false}
            />
            {imageUrl ? <Image source={{ uri: imageUrl }} style={styles.previewImg} resizeMode="cover" /> : null}
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
    backgroundColor: COLORS.header, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerSub: { color: COLORS.primary, fontSize: 10, fontWeight: '700', letterSpacing: 3 },
  headerTitle: { color: COLORS.textPrimary, fontSize: 22, fontWeight: '900' },
  createBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.primary, paddingHorizontal: SPACING.md, paddingVertical: 8, borderRadius: RADIUS.xl },
  createBtnText: { color: '#fff', fontWeight: '800', fontSize: 13 },
  list: { padding: SPACING.md, gap: SPACING.sm },
  listEmpty: { flex: 1 },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: SPACING.sm, paddingTop: 80 },
  emptyTitle: { color: COLORS.textSecondary, fontSize: 18, fontWeight: '700' },
  emptySubtitle: { color: COLORS.textMuted, fontSize: 14 },
  postCard: {
    backgroundColor: COLORS.surface, borderRadius: RADIUS.lg,
    overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border,
  },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: SPACING.md },
  postUserName: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 14 },
  postTime: { color: COLORS.textMuted, fontSize: 11 },
  postContent: { color: COLORS.textPrimary, fontSize: 15, lineHeight: 22, paddingHorizontal: SPACING.md, paddingBottom: SPACING.md },
  postImage: { width: '100%', height: 220, backgroundColor: COLORS.surfaceElevated },
  postFooter: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: SPACING.md, paddingVertical: 10,
    borderTopWidth: 1, borderTopColor: COLORS.border,
  },
  likeBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  likeCount: { color: COLORS.textMuted, fontSize: 13, fontWeight: '700' },
  footerRight: { flexDirection: 'row', gap: SPACING.md },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalBox: { backgroundColor: COLORS.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: SPACING.lg, gap: SPACING.md, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalTitle: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '800' },
  postBtn: { backgroundColor: COLORS.primary, paddingHorizontal: SPACING.md, paddingVertical: 8, borderRadius: RADIUS.xl },
  postBtnText: { color: '#fff', fontWeight: '800' },
  createRow: { flexDirection: 'row', gap: SPACING.sm, alignItems: 'flex-start' },
  postInput: { flex: 1, color: COLORS.textPrimary, fontSize: 15, minHeight: 100 },
  imageInput: { backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.md, padding: SPACING.md, color: COLORS.textPrimary, borderWidth: 1, borderColor: COLORS.border, fontSize: 13 },
  previewImg: { width: '100%', height: 160, borderRadius: RADIUS.md },
});
