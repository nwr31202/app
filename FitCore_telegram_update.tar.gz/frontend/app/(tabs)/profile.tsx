import { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image,
  Alert, Modal, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useFocusEffect } from 'expo-router';
import { useApp } from '../../src/AppContext';
import { api, clearAuth, saveAuth, getToken } from '../../src/api';
import { firebaseSignOut } from '../../src/firebaseAuth';
import { COLORS, SPACING, RADIUS } from '../../src/theme';
import { t } from '../../src/i18n';

export default function Profile() {
  const router = useRouter();
  const { user, setUser, lang, setLang } = useApp();
  const profile = user?.profile;

  const [bio, setBio] = useState(user?.bio || '');
  const [avatar, setAvatar] = useState(user?.avatar || user?.picture || '');
  const [username, setUsername] = useState(user?.username || '');
  const [editingBio, setEditingBio] = useState(false);
  const [bioInput, setBioInput] = useState(user?.bio || '');
  const [editingUsername, setEditingUsername] = useState(false);
  const [usernameInput, setUsernameInput] = useState(user?.username || '');
  const [photoModal, setPhotoModal] = useState(false);
  const [photoUrlInput, setPhotoUrlInput] = useState(user?.avatar || user?.picture || '');
  const [saving, setSaving] = useState(false);

  useFocusEffect(useCallback(() => {
    setBio(user?.bio || '');
    setAvatar(user?.avatar || user?.picture || '');
    setUsername(user?.username || '');
    setBioInput(user?.bio || '');
    setUsernameInput(user?.username || '');
    setPhotoUrlInput(user?.avatar || user?.picture || '');
  }, [user]));

  const logout = async () => {
    await firebaseSignOut();
    await clearAuth();
    setUser(null);
    router.replace('/auth/welcome');
  };

  const persistUser = async (updated: any) => {
    setUser(updated);
    const token = await getToken();
    if (token) await saveAuth(token, updated);
  };

  const saveBio = async () => {
    setSaving(true);
    try {
      await api.updateSocialProfile(bioInput, undefined);
      setBio(bioInput);
      await persistUser({ ...user, bio: bioInput });
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); }
    finally { setSaving(false); setEditingBio(false); }
  };

  const saveAvatar = async () => {
    setSaving(true);
    try {
      await api.updateSocialProfile(undefined, photoUrlInput);
      setAvatar(photoUrlInput);
      await persistUser({ ...user, avatar: photoUrlInput });
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); }
    finally { setSaving(false); setPhotoModal(false); }
  };

  const saveUsername = async () => {
    const uname = usernameInput.trim().toLowerCase();
    if (!uname) return;
    setSaving(true);
    try {
      await api.setUsername(uname);
      setUsername(uname);
      await persistUser({ ...user, username: uname });
      setEditingUsername(false);
    } catch (e: any) {
      Alert.alert(t(lang, 'error'), e.message === 'Username already taken' ? t(lang, 'usernameTaken') : e.message);
    }
    finally { setSaving(false); }
  };

  const avatarLetter = user?.name?.charAt(0)?.toUpperCase() || '?';

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

        {/* ── Avatar & Name ── */}
        <View style={styles.heroSection}>
          <TouchableOpacity style={styles.avatarWrap} onPress={() => setPhotoModal(true)} activeOpacity={0.85}>
            {avatar ? (
              <Image source={{ uri: avatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Text style={styles.avatarLetter}>{avatarLetter}</Text>
              </View>
            )}
            <View style={styles.avatarBadge}>
              <Ionicons name="camera" size={13} color="#fff" />
            </View>
          </TouchableOpacity>

          <Text style={styles.nameText}>{user?.name}</Text>

          {/* Username */}
          {editingUsername ? (
            <View style={styles.inlineEditWrap}>
              <Text style={styles.atSign}>@</Text>
              <TextInput
                style={styles.inlineInput}
                value={usernameInput}
                onChangeText={setUsernameInput}
                placeholder={t(lang, 'usernamePlaceholder')}
                placeholderTextColor={COLORS.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
                autoFocus
              />
              <TouchableOpacity onPress={() => setEditingUsername(false)} style={styles.inlineCancel}>
                <Ionicons name="close" size={16} color={COLORS.textMuted} />
              </TouchableOpacity>
              <TouchableOpacity onPress={saveUsername} style={styles.inlineSave} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="checkmark" size={16} color="#fff" />}
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity onPress={() => { setUsernameInput(username); setEditingUsername(true); }} activeOpacity={0.8} style={styles.usernameRow}>
              <Text style={styles.usernameText}>{username ? `@${username}` : t(lang, 'setUsername')}</Text>
              <Ionicons name="pencil" size={12} color={COLORS.textMuted} style={{ marginLeft: 4 }} />
            </TouchableOpacity>
          )}

          {/* Bio */}
          {editingBio ? (
            <View style={styles.bioEditWrap}>
              <TextInput
                style={styles.bioInput}
                value={bioInput}
                onChangeText={setBioInput}
                placeholder={t(lang, 'addBio')}
                placeholderTextColor={COLORS.textMuted}
                multiline
                autoFocus
                textAlignVertical="top"
              />
              <View style={styles.bioActions}>
                <TouchableOpacity onPress={() => setEditingBio(false)} style={styles.bioCancel}>
                  <Text style={styles.bioCancelText}>✕</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={saveBio} style={styles.bioSave} disabled={saving}>
                  <Text style={styles.bioSaveText}>{saving ? '...' : t(lang, 'save')}</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <TouchableOpacity onPress={() => { setBioInput(bio); setEditingBio(true); }} activeOpacity={0.8}>
              <Text style={[styles.bioText, !bio && styles.bioPlaceholder]}>
                {bio || t(lang, 'addBio')}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ── Fitness Stats ── */}
        {profile && (
          <View style={styles.statsRow}>
            <StatPill label="BMR" value={`${profile.bmr || 0}`} unit="kcal" color={COLORS.primary} />
            <StatPill label="TDEE" value={`${profile.tdee || 0}`} unit="kcal" color={COLORS.primaryLight} />
            <StatPill label={t(lang, 'goal')} value={t(lang, (profile.goal || 'maintain') as any)} color={COLORS.success} />
          </View>
        )}

        {/* ── Profile Data ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t(lang, 'profileSetup')}</Text>
          <Row label={t(lang, 'age')} value={`${profile?.age || '-'}`} />
          <Row label={t(lang, 'gender')} value={t(lang, (profile?.gender || 'male') as any)} />
          <Row label={t(lang, 'height')} value={`${profile?.height_cm || '-'} cm`} />
          <Row label={t(lang, 'weight')} value={`${profile?.weight_kg || '-'} kg`} />
          <Row label={t(lang, 'activityLevel')} value={t(lang, (profile?.activity_level || 'moderate') as any)} />
          <Row label={t(lang, 'goal')} value={t(lang, (profile?.goal || 'maintain') as any)} />
          <TouchableOpacity testID="edit-profile-btn" style={styles.editBtn} onPress={() => router.push('/onboarding')} activeOpacity={0.85}>
            <Ionicons name="create-outline" size={18} color={COLORS.textPrimary} />
            <Text style={styles.editBtnText}>{lang === 'ar' ? 'تعديل' : 'Edit'}</Text>
          </TouchableOpacity>
        </View>

        {/* ── Language ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t(lang, 'language')}</Text>
          <View style={styles.langRow}>
            <TouchableOpacity testID="lang-ar-btn" style={[styles.langBtn, lang === 'ar' && styles.langBtnActive]} onPress={() => setLang('ar')}>
              <Text style={[styles.langBtnText, lang === 'ar' && styles.langBtnTextActive]}>🇸🇦 عربي</Text>
            </TouchableOpacity>
            <TouchableOpacity testID="lang-en-btn" style={[styles.langBtn, lang === 'en' && styles.langBtnActive]} onPress={() => setLang('en')}>
              <Text style={[styles.langBtnText, lang === 'en' && styles.langBtnTextActive]}>🇺🇸 English</Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity testID="logout-btn" style={styles.logoutBtn} onPress={logout} activeOpacity={0.85}>
          <Ionicons name="log-out-outline" size={20} color={COLORS.error} />
          <Text style={styles.logoutText}>{t(lang, 'logout')}</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* ── Photo URL Modal ── */}
      <Modal visible={photoModal} transparent animationType="slide" onRequestClose={() => setPhotoModal(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>{t(lang, 'changePhoto')}</Text>
            <TextInput
              style={styles.modalInput}
              value={photoUrlInput}
              onChangeText={setPhotoUrlInput}
              placeholder={t(lang, 'photoUrl')}
              placeholderTextColor={COLORS.textMuted}
              autoCapitalize="none"
              autoCorrect={false}
            />
            {photoUrlInput ? (
              <Image source={{ uri: photoUrlInput }} style={styles.previewImg} resizeMode="cover" />
            ) : null}
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.modalCancel} onPress={() => setPhotoModal(false)}>
                <Text style={styles.modalCancelText}>{lang === 'ar' ? 'إلغاء' : 'Cancel'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalSave} onPress={saveAvatar} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.modalSaveText}>{t(lang, 'save')}</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

function StatPill({ label, value, unit, color }: { label: string; value: string; unit?: string; color: string }) {
  return (
    <View style={[styles.statPill, { borderColor: color + '40' }]}>
      <Text style={[styles.statPillValue, { color }]}>{value}</Text>
      {unit && <Text style={styles.statPillUnit}>{unit}</Text>}
      <Text style={styles.statPillLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingBottom: SPACING.xxl },

  heroSection: { alignItems: 'center', gap: SPACING.sm, paddingTop: SPACING.xl, paddingBottom: SPACING.lg, paddingHorizontal: SPACING.lg },
  avatarWrap: { position: 'relative' },
  avatar: { width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: COLORS.primary },
  avatarPlaceholder: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: COLORS.primaryDark, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: COLORS.primary,
  },
  avatarLetter: { color: '#fff', fontSize: 36, fontWeight: '900' },
  avatarBadge: {
    position: 'absolute', bottom: 2, right: 2,
    backgroundColor: COLORS.primary, borderRadius: 12, padding: 5,
    borderWidth: 2, borderColor: COLORS.background,
  },
  nameText: { color: COLORS.textPrimary, fontSize: 22, fontWeight: '900' },

  usernameRow: { flexDirection: 'row', alignItems: 'center' },
  usernameText: { color: COLORS.primary, fontSize: 14, fontWeight: '600' },

  inlineEditWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.xl,
    paddingHorizontal: SPACING.sm, paddingVertical: 6,
    borderWidth: 1, borderColor: COLORS.primary,
  },
  atSign: { color: COLORS.primary, fontWeight: '700', fontSize: 14 },
  inlineInput: { color: COLORS.textPrimary, fontSize: 14, minWidth: 120, maxWidth: 180 },
  inlineCancel: { padding: 4 },
  inlineSave: { backgroundColor: COLORS.primary, borderRadius: RADIUS.md, padding: 6 },

  bioText: { color: COLORS.textSecondary, fontSize: 14, textAlign: 'center', maxWidth: 260 },
  bioPlaceholder: { color: COLORS.textMuted, fontStyle: 'italic' },
  bioEditWrap: { width: '100%', gap: SPACING.sm },
  bioInput: {
    backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.md, padding: SPACING.md,
    color: COLORS.textPrimary, borderWidth: 1, borderColor: COLORS.border,
    fontSize: 14, minHeight: 70, textAlignVertical: 'top',
  },
  bioActions: { flexDirection: 'row', gap: SPACING.sm, justifyContent: 'flex-end' },
  bioCancel: { paddingHorizontal: SPACING.md, paddingVertical: 8, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border },
  bioCancelText: { color: COLORS.textSecondary },
  bioSave: { paddingHorizontal: SPACING.md, paddingVertical: 8, borderRadius: RADIUS.md, backgroundColor: COLORS.primary },
  bioSaveText: { color: '#fff', fontWeight: '700' },

  statsRow: { flexDirection: 'row', gap: SPACING.sm, paddingHorizontal: SPACING.lg, marginBottom: SPACING.sm },
  statPill: { flex: 1, backgroundColor: COLORS.surface, borderWidth: 1, borderRadius: RADIUS.md, padding: SPACING.sm, alignItems: 'center', gap: 2 },
  statPillValue: { fontSize: 16, fontWeight: '900' },
  statPillUnit: { color: COLORS.textMuted, fontSize: 9, fontWeight: '600' },
  statPillLabel: { color: COLORS.textSecondary, fontSize: 9, fontWeight: '700', letterSpacing: 0.5, textTransform: 'uppercase' },

  card: { marginHorizontal: SPACING.lg, marginBottom: SPACING.sm, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.md, padding: SPACING.md, gap: SPACING.sm },
  cardTitle: { color: COLORS.textPrimary, fontSize: 13, fontWeight: '800', letterSpacing: 0.5, marginBottom: 4 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border },
  rowLabel: { color: COLORS.textSecondary, fontSize: 13 },
  rowValue: { color: COLORS.textPrimary, fontWeight: '700' },
  editBtn: { flexDirection: 'row', gap: 6, alignSelf: 'flex-start', paddingHorizontal: SPACING.md, paddingVertical: 10, borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.md, marginTop: SPACING.sm },
  editBtnText: { color: COLORS.textPrimary, fontWeight: '700' },

  langRow: { flexDirection: 'row', gap: SPACING.sm },
  langBtn: { flex: 1, paddingVertical: 13, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', backgroundColor: COLORS.surfaceElevated },
  langBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  langBtnText: { color: COLORS.textSecondary, fontWeight: '700' },
  langBtnTextActive: { color: '#fff' },

  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: SPACING.sm, marginHorizontal: SPACING.lg, paddingVertical: 16, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.error, marginTop: SPACING.sm },
  logoutText: { color: COLORS.error, fontWeight: '800', letterSpacing: 1 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalBox: { backgroundColor: COLORS.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: SPACING.lg, gap: SPACING.md },
  modalTitle: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '800', textAlign: 'center' },
  modalInput: { backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.md, padding: SPACING.md, color: COLORS.textPrimary, borderWidth: 1, borderColor: COLORS.border },
  previewImg: { width: '100%', height: 160, borderRadius: RADIUS.md, backgroundColor: COLORS.surfaceElevated },
  modalActions: { flexDirection: 'row', gap: SPACING.sm },
  modalCancel: { flex: 1, paddingVertical: 14, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center' },
  modalCancelText: { color: COLORS.textSecondary, fontWeight: '700' },
  modalSave: { flex: 1, paddingVertical: 14, borderRadius: RADIUS.md, backgroundColor: COLORS.primary, alignItems: 'center' },
  modalSaveText: { color: '#fff', fontWeight: '800' },
});
