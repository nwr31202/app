import { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Image, Vibration,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useApp } from '../../../src/AppContext';
import { api } from '../../../src/api';
import { COLORS, SPACING, RADIUS } from '../../../src/theme';
import { t } from '../../../src/i18n';

function Avatar({ uri, name, size = 32 }: { uri?: string; name: string; size?: number }) {
  const letter = (name || '?').charAt(0).toUpperCase();
  const colors = ['#C80000', '#8B0000', '#B71C1C', '#7B1FA2', '#1565C0'];
  const color = colors[letter.charCodeAt(0) % colors.length];
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '700', fontSize: size * 0.4 }}>{letter}</Text>
    </View>
  );
}

function formatTime(dateStr: string) {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDate(dateStr: string, lang: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return lang === 'ar' ? 'اليوم' : 'Today';
  if (d.toDateString() === yesterday.toDateString()) return lang === 'ar' ? 'أمس' : 'Yesterday';
  return d.toLocaleDateString(lang === 'ar' ? 'ar-SA' : 'en-US', { day: 'numeric', month: 'long' });
}

export default function GroupChat() {
  const router = useRouter();
  const { groupId, groupName } = useLocalSearchParams<{ groupId: string; groupName: string }>();
  const { user, lang } = useApp();
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [memberCount, setMemberCount] = useState(0);
  const flatRef = useRef<FlatList>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    try {
      const [msgData, groupData] = await Promise.all([
        api.getGroupMessages(groupId),
        api.getGroup(groupId).catch(() => null),
      ]);
      setMessages(msgData.messages || []);
      if (groupData) setMemberCount(groupData.members?.length || 0);
    } catch {} finally { setLoading(false); }
  }, [groupId]);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [load]);

  useEffect(() => {
    if (messages.length > 0) setTimeout(() => flatRef.current?.scrollToEnd({ animated: false }), 50);
  }, [messages.length]);

  const send = async () => {
    const text = input.trim();
    if (!text || sending) return;
    setInput('');
    setSending(true);
    try {
      const msg = await api.sendGroupMessage(groupId, text);
      setMessages(prev => [...prev, msg]);
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); setInput(text); }
    finally { setSending(false); }
  };

  const handleLeave = () => {
    Alert.alert(
      t(lang, 'leaveGroup'),
      lang === 'ar' ? 'هل تريد مغادرة هذه المجموعة؟' : 'Are you sure you want to leave?',
      [
        { text: lang === 'ar' ? 'إلغاء' : 'Cancel', style: 'cancel' },
        {
          text: t(lang, 'leaveGroup'), style: 'destructive',
          onPress: async () => {
            try { await api.leaveGroup(groupId); router.back(); } catch {}
          },
        },
      ],
    );
  };

  // Group messages by date
  const grouped: { type: 'date' | 'msg'; data: any; id: string }[] = [];
  let lastDate = '';
  for (const msg of messages) {
    const dateKey = new Date(msg.created_at).toDateString();
    if (dateKey !== lastDate) {
      grouped.push({ type: 'date', data: msg.created_at, id: `date-${dateKey}` });
      lastDate = dateKey;
    }
    grouped.push({ type: 'msg', data: msg, id: msg.id });
  }

  const renderItem = ({ item }: { item: typeof grouped[0] }) => {
    if (item.type === 'date') {
      return (
        <View style={styles.dateSep}>
          <Text style={styles.dateText}>{formatDate(item.data, lang)}</Text>
        </View>
      );
    }
    const msg = item.data;
    const isMine = msg.from_user_id === user?.id;
    return (
      <View style={[styles.msgRow, isMine ? styles.msgRowRight : styles.msgRowLeft]}>
        {!isMine && <Avatar uri={msg.from_user_avatar} name={msg.from_user_name} size={28} />}
        <View style={[styles.bubble, isMine ? styles.bubbleMine : styles.bubbleOther]}>
          {!isMine && <Text style={styles.senderName}>{msg.from_user_name}</Text>}
          <Text style={styles.bubbleText}>{msg.content}</Text>
          <Text style={styles.bubbleTime}>{formatTime(msg.created_at)}</Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <View style={styles.groupAvatar}>
            <Ionicons name="people" size={20} color={COLORS.primary} />
          </View>
          <View>
            <Text style={styles.headerName}>{groupName}</Text>
            <Text style={styles.headerSub}>{memberCount} {t(lang, 'members')}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.hBtn} onPress={handleLeave}>
          <Ionicons name="exit-outline" size={22} color={COLORS.error} />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={COLORS.primary} size="large" /></View>
      ) : (
        <FlatList
          ref={flatRef}
          data={grouped}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.msgList}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name="people-outline" size={60} color={COLORS.border} />
              <Text style={styles.emptyTitle}>{groupName}</Text>
              <Text style={styles.emptyHint}>{lang === 'ar' ? 'ابدأ المحادثة في المجموعة' : 'Start the group conversation'}</Text>
            </View>
          }
        />
      )}

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.inputBar}>
          <View style={styles.inputWrap}>
            <TextInput
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder={t(lang, 'typeMessage')}
              placeholderTextColor={COLORS.textMuted}
              multiline
              maxLength={2000}
              onSubmitEditing={send}
              blurOnSubmit={false}
            />
          </View>
          {input.trim() ? (
            <TouchableOpacity style={styles.sendBtn} onPress={send} disabled={sending}>
              {sending ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="send" size={20} color="#fff" />}
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={[styles.sendBtn, { backgroundColor: COLORS.surfaceElevated }]}>
              <Ionicons name="mic-outline" size={22} color={COLORS.textMuted} />
            </TouchableOpacity>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: SPACING.sm, paddingVertical: 8,
    backgroundColor: COLORS.header, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  backBtn: { padding: 8 },
  headerCenter: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, marginLeft: 4 },
  groupAvatar: {
    width: 38, height: 38, borderRadius: 19, backgroundColor: '#1A0A0A',
    alignItems: 'center', justifyContent: 'center',
  },
  headerName: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '700' },
  headerSub: { color: COLORS.textMuted, fontSize: 11 },
  hBtn: { padding: 8 },
  msgList: { paddingVertical: SPACING.sm, paddingHorizontal: SPACING.sm, gap: 2 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', marginVertical: 2, gap: 6 },
  msgRowRight: { justifyContent: 'flex-end' },
  msgRowLeft: { justifyContent: 'flex-start' },
  bubble: { maxWidth: '78%', paddingHorizontal: 12, paddingVertical: 8, borderRadius: RADIUS.bubble, gap: 2 },
  bubbleMine: { backgroundColor: COLORS.bubbleMine, borderBottomRightRadius: 4 },
  bubbleOther: { backgroundColor: COLORS.bubbleOther, borderBottomLeftRadius: 4, borderWidth: 1, borderColor: COLORS.border },
  senderName: { color: COLORS.primaryLight, fontSize: 12, fontWeight: '700', marginBottom: 2 },
  bubbleText: { color: '#FFFFFF', fontSize: 15, lineHeight: 21 },
  bubbleTime: { color: 'rgba(255,255,255,0.45)', fontSize: 10, alignSelf: 'flex-end' },
  dateSep: { alignItems: 'center', marginVertical: 12 },
  dateText: { color: COLORS.textMuted, fontSize: 12, backgroundColor: COLORS.surfaceElevated, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12 },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80, gap: SPACING.sm },
  emptyTitle: { color: COLORS.textPrimary, fontSize: 20, fontWeight: '700' },
  emptyHint: { color: COLORS.textMuted, fontSize: 14 },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 8,
    paddingHorizontal: 12, paddingVertical: 8,
    backgroundColor: COLORS.header, borderTopWidth: 1, borderTopColor: COLORS.border,
  },
  inputWrap: { flex: 1 },
  input: {
    backgroundColor: COLORS.inputBg, borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10,
    color: COLORS.textPrimary, fontSize: 15, borderWidth: 1, borderColor: COLORS.border, maxHeight: 120,
  },
  sendBtn: { backgroundColor: COLORS.primary, width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
});
