import { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Image, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useApp } from '../../../src/AppContext';
import { api } from '../../../src/api';
import { COLORS, SPACING, RADIUS } from '../../../src/theme';
import { t } from '../../../src/i18n';

function timeAgo(dateStr: string, lang: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return lang === 'ar' ? 'الآن' : 'Just now';
  if (mins < 60) return lang === 'ar' ? `منذ ${mins} دقيقة` : `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return lang === 'ar' ? `منذ ${hrs} ساعة` : `${hrs}h ago`;
  return lang === 'ar' ? `منذ ${Math.floor(hrs / 24)} يوم` : `${Math.floor(hrs / 24)}d ago`;
}

export default function ChannelScreen() {
  const router = useRouter();
  const { channelId, channelName } = useLocalSearchParams<{ channelId: string; channelName: string }>();
  const { user, lang } = useApp();
  const [posts, setPosts] = useState<any[]>([]);
  const [channel, setChannel] = useState<any>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showPost, setShowPost] = useState(false);
  const [postContent, setPostContent] = useState('');
  const [postImage, setPostImage] = useState('');
  const [posting, setPosting] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api.getChannelPosts(channelId);
      setPosts(data.posts || []);
      setChannel(data.channel);
      setIsOwner(data.is_owner);
      setSubscribed(data.subscribed);
    } catch {} finally { setLoading(false); }
  }, [channelId]);

  useEffect(() => { load(); }, [load]);

  const handleSubscribe = async () => {
    try {
      const res = await api.subscribeChannel(channelId);
      setSubscribed(res.subscribed);
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); }
  };

  const submitPost = async () => {
    if (!postContent.trim()) return;
    setPosting(true);
    try {
      const p = await api.postToChannel(channelId, postContent.trim(), postImage.trim() || undefined);
      setPosts(prev => [p, ...prev]);
      setPostContent('');
      setPostImage('');
      setShowPost(false);
    } catch (e: any) { Alert.alert(t(lang, 'error'), e.message); }
    finally { setPosting(false); }
  };

  const renderPost = ({ item }: { item: any }) => (
    <View style={styles.postCard}>
      <View style={styles.postHeader}>
        <View style={styles.channelIcon}>
          <Ionicons name="megaphone" size={16} color={COLORS.primaryLight} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.channelNameText}>{item.channel_name || channelName}</Text>
          <Text style={styles.postTime}>{timeAgo(item.created_at, lang)}</Text>
        </View>
        {isOwner && (
          <Text style={styles.ownerBadge}>{t(lang, 'isOwner')}</Text>
        )}
      </View>
      <Text style={styles.postContent}>{item.content}</Text>
      {item.image ? (
        <Image source={{ uri: item.image }} style={styles.postImg} resizeMode="cover" />
      ) : null}
      <View style={styles.postMeta}>
        <Ionicons name="eye-outline" size={13} color={COLORS.textMuted} />
        <Text style={styles.postViews}>{item.views || 0}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <View style={styles.channelAvatar}>
            <Ionicons name="megaphone" size={18} color={COLORS.primaryLight} />
          </View>
          <View>
            <Text style={styles.headerName}>{channelName}</Text>
            {channel && <Text style={styles.headerSub}>{channel.subscriber_count || 0} {t(lang, 'subscribers')}</Text>}
          </View>
        </View>
        {!isOwner ? (
          <TouchableOpacity
            style={[styles.subBtn, subscribed && styles.subBtnActive]}
            onPress={handleSubscribe}
          >
            <Text style={[styles.subBtnText, subscribed && styles.subBtnTextActive]}>
              {subscribed ? t(lang, 'subscribed') : t(lang, 'subscribe')}
            </Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.postBtn} onPress={() => setShowPost(true)}>
            <Ionicons name="add" size={20} color="#fff" />
          </TouchableOpacity>
        )}
      </View>

      {/* Channel description */}
      {channel?.description ? (
        <View style={styles.descBar}>
          <Text style={styles.descText}>{channel.description}</Text>
        </View>
      ) : null}

      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={COLORS.primary} size="large" /></View>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={item => item.id}
          renderItem={renderPost}
          contentContainerStyle={[styles.list, posts.length === 0 && styles.listEmpty]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name="megaphone-outline" size={60} color={COLORS.border} />
              <Text style={styles.emptyTitle}>{t(lang, 'noChannels')}</Text>
              {isOwner && (
                <TouchableOpacity style={styles.firstPostBtn} onPress={() => setShowPost(true)}>
                  <Text style={styles.firstPostText}>{t(lang, 'postToChannel')}</Text>
                </TouchableOpacity>
              )}
            </View>
          }
        />
      )}

      {isOwner && (
        <TouchableOpacity style={styles.fab} onPress={() => setShowPost(true)}>
          <Ionicons name="add" size={28} color="#fff" />
        </TouchableOpacity>
      )}

      {/* Post Modal */}
      <Modal visible={showPost} animationType="slide" transparent onRequestClose={() => setShowPost(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={styles.modalBg}>
            <View style={styles.modalBox}>
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setShowPost(false)}>
                  <Ionicons name="close" size={24} color={COLORS.textSecondary} />
                </TouchableOpacity>
                <Text style={styles.modalTitle}>{t(lang, 'postToChannel')}</Text>
                <TouchableOpacity
                  style={[styles.sendMsgBtn, (!postContent.trim() || posting) && { opacity: 0.4 }]}
                  onPress={submitPost}
                  disabled={!postContent.trim() || posting}
                >
                  {posting ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.sendMsgText}>{t(lang, 'post')}</Text>}
                </TouchableOpacity>
              </View>
              <TextInput
                style={styles.postInput}
                value={postContent}
                onChangeText={setPostContent}
                placeholder={t(lang, 'writePost')}
                placeholderTextColor={COLORS.textMuted}
                multiline
                autoFocus
                textAlignVertical="top"
              />
              <TextInput
                style={styles.urlInput}
                value={postImage}
                onChangeText={setPostImage}
                placeholder={t(lang, 'addImageUrl')}
                placeholderTextColor={COLORS.textMuted}
                autoCapitalize="none"
              />
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: COLORS.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: SPACING.sm, paddingVertical: 8,
    backgroundColor: COLORS.header, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  backBtn: { padding: 8 },
  headerCenter: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, marginLeft: 4 },
  channelAvatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#1A0000', alignItems: 'center', justifyContent: 'center' },
  headerName: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '700' },
  headerSub: { color: COLORS.textMuted, fontSize: 11 },
  subBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: RADIUS.xl, borderWidth: 1, borderColor: COLORS.primary, marginRight: 4 },
  subBtnActive: { backgroundColor: COLORS.primary },
  subBtnText: { color: COLORS.primary, fontSize: 13, fontWeight: '700' },
  subBtnTextActive: { color: '#fff' },
  postBtn: { backgroundColor: COLORS.primary, width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginRight: 4 },
  descBar: { backgroundColor: COLORS.surfaceElevated, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  descText: { color: COLORS.textSecondary, fontSize: 13 },
  list: { padding: SPACING.md, gap: SPACING.md },
  listEmpty: { flex: 1 },
  postCard: { backgroundColor: COLORS.surface, borderRadius: RADIUS.lg, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  postHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  channelIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#1A0000', alignItems: 'center', justifyContent: 'center' },
  channelNameText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 14 },
  postTime: { color: COLORS.textMuted, fontSize: 11 },
  ownerBadge: { color: COLORS.primaryLight, fontSize: 10, fontWeight: '700', borderWidth: 1, borderColor: COLORS.primaryLight, paddingHorizontal: 6, paddingVertical: 2, borderRadius: RADIUS.sm },
  postContent: { color: COLORS.textPrimary, fontSize: 15, lineHeight: 22, padding: SPACING.md },
  postImg: { width: '100%', height: 220, backgroundColor: COLORS.surfaceElevated },
  postMeta: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderTopWidth: 1, borderTopColor: COLORS.border },
  postViews: { color: COLORS.textMuted, fontSize: 11 },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80, gap: SPACING.md },
  emptyTitle: { color: COLORS.textMuted, fontSize: 16 },
  firstPostBtn: { backgroundColor: COLORS.primary, paddingHorizontal: SPACING.lg, paddingVertical: 10, borderRadius: RADIUS.xl },
  firstPostText: { color: '#fff', fontWeight: '700' },
  fab: {
    position: 'absolute', bottom: 24, right: 24,
    backgroundColor: COLORS.primary, width: 56, height: 56, borderRadius: 28,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 8, elevation: 8,
  },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalBox: { backgroundColor: COLORS.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: SPACING.lg, gap: SPACING.md, minHeight: 300 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalTitle: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '700' },
  sendMsgBtn: { backgroundColor: COLORS.primary, paddingHorizontal: SPACING.md, paddingVertical: 7, borderRadius: RADIUS.xl },
  sendMsgText: { color: '#fff', fontWeight: '700' },
  postInput: { color: COLORS.textPrimary, fontSize: 15, minHeight: 120, textAlignVertical: 'top', borderBottomWidth: 1, borderBottomColor: COLORS.border, paddingBottom: 8 },
  urlInput: { backgroundColor: COLORS.surfaceElevated, borderRadius: RADIUS.md, padding: SPACING.md, color: COLORS.textPrimary, borderWidth: 1, borderColor: COLORS.border, fontSize: 13 },
});
