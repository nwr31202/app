// Theme — Telegram-inspired Dark (Black + Red)
export const COLORS = {
  // Backgrounds
  background: '#000000',
  surface: '#0F0F10',
  surfaceElevated: '#1A1A1C',
  surfaceHighest: '#232325',

  // Brand
  primary: '#C80000',
  primaryLight: '#E53935',
  primaryDark: '#8B0000',

  // Chat bubbles
  bubbleMine: '#8B0000',
  bubbleOther: '#1C1C1E',

  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#AAAAAA',
  textMuted: '#666666',
  textOnRed: '#FFFFFF',

  // UI elements
  border: '#2A2A2C',
  separator: '#1E1E20',
  header: '#111113',
  tabBar: '#0A0A0B',
  inputBg: '#1A1A1C',

  // Status
  success: '#4CAF50',
  warning: '#FF9800',
  error: '#FF4444',
  online: '#4CAF50',
  unread: '#C80000',

  // Secondary accent
  secondary: '#C80000',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const RADIUS = {
  sm: 4,
  md: 10,
  lg: 16,
  xl: 22,
  bubble: 18,
};

export const FONTS = {
  regular: { fontWeight: '400' as const },
  medium: { fontWeight: '500' as const },
  semibold: { fontWeight: '600' as const },
  bold: { fontWeight: '700' as const },
  black: { fontWeight: '900' as const },
};
