import AsyncStorage from '@react-native-async-storage/async-storage';
import { Lang } from './i18n';

const BASE_URL = process.env.EXPO_PUBLIC_BACKEND_URL;

export type User = {
  id: string;
  email: string;
  name: string;
  username?: string;
  profile?: any;
  language?: Lang;
  bio?: string;
  avatar?: string;
  picture?: string;
};

async function authHeaders() {
  const token = await AsyncStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request(path: string, options: RequestInit = {}) {
  const headers = await authHeaders();
  const res = await fetch(`${BASE_URL}/api${path}`, {
    ...options,
    headers: { ...headers, ...(options.headers || {}) },
  });
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new Error(data?.detail || `Request failed ${res.status}`);
  return data;
}

export const api = {
  // Auth
  signup: (email: string, password: string, name: string) =>
    request('/auth/signup', { method: 'POST', body: JSON.stringify({ email, password, name }) }),
  login: (email: string, password: string) =>
    request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  me: () => request('/auth/me'),
  meFullProfile: () => request('/user/me/full'),

  // Profile
  saveProfile: (profile: any) =>
    request('/profile', { method: 'POST', body: JSON.stringify(profile) }),
  getProfile: () => request('/profile'),

  // Social Profile
  updateSocialProfile: (bio?: string, avatar?: string) =>
    request('/social/profile', { method: 'PATCH', body: JSON.stringify({ bio, avatar }) }),
  getSocialProfile: (userId: string) => request(`/social/profile/${userId}`),

  // Username
  setUsername: (username: string) =>
    request('/user/username', { method: 'PATCH', body: JSON.stringify({ username }) }),

  // User Search
  searchUsers: (q: string) => request(`/users/search?q=${encodeURIComponent(q)}`),

  // Plans
  generateWorkout: (language: Lang) =>
    request('/plans/workout', { method: 'POST', body: JSON.stringify({ language }) }),
  generateNutrition: (language: Lang) =>
    request('/plans/nutrition', { method: 'POST', body: JSON.stringify({ language }) }),
  latestPlan: (type: 'workout' | 'nutrition') => request(`/plans/latest/${type}`),

  // Food
  logFood: (food: any) =>
    request('/food/log', { method: 'POST', body: JSON.stringify(food) }),
  foodToday: () => request('/food/today'),
  deleteFood: (id: string) => request(`/food/log/${id}`, { method: 'DELETE' }),
  estimateFood: (description: string, language: string) =>
    request('/food/estimate', { method: 'POST', body: JSON.stringify({ description, language }) }),

  // Weight
  logWeight: (weight_kg: number) =>
    request('/weight/log', { method: 'POST', body: JSON.stringify({ weight_kg }) }),
  weightHistory: () => request('/weight/history'),

  // Auth providers
  googleAuth: (session_token: string) =>
    request('/auth/google', { method: 'POST', body: JSON.stringify({ session_token }) }),
  firebaseAuth: (id_token: string) =>
    request('/auth/firebase', { method: 'POST', body: JSON.stringify({ id_token }) }),

  // Runs
  saveRun: (run: any) =>
    request('/runs', { method: 'POST', body: JSON.stringify(run) }),
  listRuns: () => request('/runs'),
  runStats: () => request('/runs/stats'),
  setGoal: (distance_km: number) =>
    request('/goals', { method: 'POST', body: JSON.stringify({ distance_km }) }),
  getGoal: () => request('/goals'),

  // Posts / Feed
  createPost: (content: string, image?: string) =>
    request('/posts', { method: 'POST', body: JSON.stringify({ content, image }) }),
  getFeed: () => request('/posts/feed'),
  likePost: (postId: string) => request(`/posts/${postId}/like`, { method: 'POST' }),
  deletePost: (postId: string) => request(`/posts/${postId}`, { method: 'DELETE' }),

  // Direct Messages
  sendMessage: (to_user_id: string, content: string) =>
    request('/messages', { method: 'POST', body: JSON.stringify({ to_user_id, content }) }),
  getConversation: (otherUserId: string) => request(`/messages/${otherUserId}`),
  getConversations: () => request('/conversations'),

  // Groups
  createGroup: (name: string, description: string, member_ids: string[]) =>
    request('/groups', { method: 'POST', body: JSON.stringify({ name, description, member_ids }) }),
  listGroups: () => request('/groups'),
  getGroup: (groupId: string) => request(`/groups/${groupId}`),
  addGroupMember: (groupId: string, user_id: string) =>
    request(`/groups/${groupId}/members`, { method: 'POST', body: JSON.stringify({ user_id }) }),
  leaveGroup: (groupId: string) =>
    request(`/groups/${groupId}/leave`, { method: 'DELETE' }),
  sendGroupMessage: (groupId: string, content: string) =>
    request(`/groups/${groupId}/messages`, { method: 'POST', body: JSON.stringify({ content }) }),
  getGroupMessages: (groupId: string) => request(`/groups/${groupId}/messages`),

  // Channels
  createChannel: (name: string, description: string) =>
    request('/channels', { method: 'POST', body: JSON.stringify({ name, description }) }),
  listAllChannels: () => request('/channels'),
  myChannels: () => request('/channels/mine'),
  subscribeChannel: (channelId: string) =>
    request(`/channels/${channelId}/subscribe`, { method: 'POST' }),
  postToChannel: (channelId: string, content: string, image?: string) =>
    request(`/channels/${channelId}/posts`, { method: 'POST', body: JSON.stringify({ content, image }) }),
  getChannelPosts: (channelId: string) => request(`/channels/${channelId}/posts`),
};

export async function saveAuth(token: string, user: User) {
  await AsyncStorage.setItem('token', token);
  await AsyncStorage.setItem('user', JSON.stringify(user));
}

export async function getStoredUser(): Promise<User | null> {
  const u = await AsyncStorage.getItem('user');
  return u ? JSON.parse(u) : null;
}

export async function getStoredLang(): Promise<Lang> {
  const l = await AsyncStorage.getItem('lang');
  return (l as Lang) || 'ar';
}

export async function setStoredLang(lang: Lang) {
  await AsyncStorage.setItem('lang', lang);
}

export async function clearAuth() {
  await AsyncStorage.removeItem('token');
  await AsyncStorage.removeItem('user');
}

export async function getToken(): Promise<string | null> {
  return AsyncStorage.getItem('token');
}
